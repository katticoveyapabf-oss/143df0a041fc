// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lower to A-normal form\n", stdout);
  return lionss_run_workload("anf-lower");
}
