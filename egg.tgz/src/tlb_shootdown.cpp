// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Measure TLB shootdown\n", stdout);
  return lionss_run_workload("tlb_shootdown");
}
