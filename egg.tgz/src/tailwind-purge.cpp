// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Purge unused classes"); }
int main(){
  announce();
  return lionss_run_workload("tailwind-purge");
}
