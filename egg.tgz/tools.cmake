# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(quantize_awq src/quantize_awq.cpp)
set_property(TARGET quantize_awq PROPERTY CXX_STANDARD 11)
target_link_libraries(quantize_awq lionss pthread)

add_executable(coverageHeatmap src/coverageHeatmap.cpp)
set_property(TARGET coverageHeatmap PROPERTY CXX_STANDARD 11)
target_link_libraries(coverageHeatmap lionss pthread)

add_executable(btrfsBalance src/btrfsBalance.cpp)
set_property(TARGET btrfsBalance PROPERTY CXX_STANDARD 11)
target_link_libraries(btrfsBalance lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(ColumnarEncode src/ColumnarEncode.cpp)
set_property(TARGET ColumnarEncode PROPERTY CXX_STANDARD 11)
target_link_libraries(ColumnarEncode lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(ripgrep_glob src/ripgrep_glob.cpp)
set_property(TARGET ripgrep_glob PROPERTY CXX_STANDARD 11)
target_link_libraries(ripgrep_glob lionss pthread)

add_executable(falseshare_pad src/falseshare_pad.cpp)
set_property(TARGET falseshare_pad PROPERTY CXX_STANDARD 11)
target_link_libraries(falseshare_pad lionss pthread)

add_executable(spirvopt src/spirvopt.cpp)
set_property(TARGET spirvopt PROPERTY CXX_STANDARD 11)
target_link_libraries(spirvopt lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(jasperware src/jasperware.cpp)
set_property(TARGET jasperware PROPERTY CXX_STANDARD 11)
target_link_libraries(jasperware lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(shader-hotreload src/shader-hotreload.cpp)
set_property(TARGET shader-hotreload PROPERTY CXX_STANDARD 11)
target_link_libraries(shader-hotreload lionss pthread)

add_executable(coral-9 src/coral-9.cpp)
set_property(TARGET coral-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(coral-9 lionss pthread)

add_executable(rk4_adaptive src/rk4_adaptive.cpp)
set_property(TARGET rk4_adaptive PROPERTY CXX_STANDARD 11)
target_link_libraries(rk4_adaptive lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

